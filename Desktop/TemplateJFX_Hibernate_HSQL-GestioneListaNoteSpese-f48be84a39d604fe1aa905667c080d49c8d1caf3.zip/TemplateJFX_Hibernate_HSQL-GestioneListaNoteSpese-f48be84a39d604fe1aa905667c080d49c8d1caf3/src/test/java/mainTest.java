import com.nsi.rsni.pojo.NotaSpesa;
import com.nsi.rsni.service.NotaSpesaService;
import org.junit.Test;

import static org.junit.Assert.assertTrue;
/**
 * Created by acerioni on 06/09/2016.
 */
public class mainTest {

    @Test
    public void inserisciNoteSpese(){

        NotaSpesaService notaSpesaService = new NotaSpesaService();

        //@TODO
        String id = null;

        assertTrue(id != null);

    }
}
