package com.nsi.rsni.controller;

import com.nsi.rsni.service.NotaSpesaService;
import com.nsi.rsni.pojo.pojoFX.NotaSpesaFx;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

/**
 * Created by v.chiuselli on 02/12/2016.
 */

public class listaNotaSpesaController {


    @FXML
    public AnchorPane anchorPane;
    @FXML
    public TableView tableView;
    @FXML
    public TableColumn agenteColumn;
    @FXML
    public TableColumn<NotaSpesaFx, String> matricolaColumn;
    @FXML
    public TableColumn ufficioColumn;
    @FXML
    public TableColumn viaggioColumn;
    @FXML
    public TableColumn prtenzaColumn;
    @FXML
    public TableColumn ritornoColumn;
    @FXML
    public TableColumn tipiSpeseColumn;


    @FXML
    public void initialize() throws Exception {

        NotaSpesaService notaSpesaService = new NotaSpesaService();


        ObservableList<NotaSpesaFx> listaNotaSpese = notaSpesaService.getListNotaSpesaFx();


        matricolaColumn.setCellValueFactory(new PropertyValueFactory<NotaSpesaFx,String>("_matricola"));
        //TODO


        tableView.setItems(listaNotaSpese);


    }


}

