


package com.nsi.rsni.controller;


import java.io.IOException;

import com.nsi.rsni.dao.impl.NotaSpesaDaoImpl;
import com.nsi.rsni.dao.impl.TipoSpesaDaoImpl;
import com.nsi.rsni.pojo.TipoSpesa;
import com.nsi.rsni.pojo.pojoFX.TipoSpesaFx;
import com.nsi.rsni.service.NotaSpesaService;
import com.nsi.rsni.service.TipoSpesaService;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class crudNotaSpesaController {

    @FXML
    private AnchorPane mixPane;

    @FXML
    private Button buttonSalva;

    @FXML
    private TextField agenteField;

    @FXML
    private TextField ufficioField;

    @FXML
    private TextField partenzaField;

    @FXML
    private TextField matricolaField;

    @FXML
    private TextField viaggioField;

    @FXML
    private TextField ritornoField;

    @FXML
    private TextField idField;

    @FXML
    private Label error1;

    @FXML
    private Label error2;

    @FXML
    private Label error3;

    @FXML
    private Label error4;

    @FXML
    private Label error5;

    @FXML
    private Label error6;

    @FXML
    private Label error8;

    @FXML
    private Label error10;

    @FXML
    private Label error11;

    @FXML
    private Label error12;

    @FXML
    private Label error13;

    @FXML
    private Label error14;

    @FXML
    private Label error15;

    @FXML
    private Label error16;

    @FXML
    private Label error17;

    @FXML
    private Label error20;

    @FXML
    private Label error21;

    @FXML
    private Label error22;

    @FXML
    private TableView<TipoSpesa> tabelMix;

    @FXML
    private TableColumn<TipoSpesa, String> idColumn;

    @FXML
    private TableColumn<TipoSpesa, String> descrizioneColumn;

    @FXML
    private TableColumn<TipoSpesa, Integer> importoColumn;

    @FXML
    private TableColumn<TipoSpesa, Integer> ivaCollumn;

    @FXML
    private Button inserisciNuovoTipoSpesa;

    @FXML
    ComboBox<String> TipiSpesecomboBoxMix;

    @FXML
    private Button inserisciTS;

    //spostato tutto da initialite a sopra....

    ObservableList<TipoSpesa> tipoSpesaList = FXCollections.observableArrayList();
    // ObservableList<TipoSpesa> aggiungiTipoSpesaLista = FXCollections.observableArrayList();

    private TipoSpesaDaoImpl dao = new TipoSpesaDaoImpl();

    // ObservableList<String> listad = dao.mostraDescrizioni();

    @FXML
    public void initialize() throws Exception {

        TipoSpesaService tipoSpesaService = new TipoSpesaService();


        //   tipoSpesaService.insertTipoSpesaFx("uffa", "1.000", "22%");
        //     tipoSpesaService.insertTipoSpesaFx("altro", "87", "12%");
        //    tipoSpesaService.insertTipoSpesaFx("dai", "a000", "sdsa%");


        TipiSpesecomboBoxMix.setItems(tipoSpesaService.getListTipoSpesaDescrizioniFx());


    }


    @FXML
    void aggiungiTipoSpesa(ActionEvent event) throws Exception {
        TipoSpesaService tipoSpesaService = new TipoSpesaService();
        TipoSpesaFx tipoSpesaFx = tipoSpesaService.getByDescrizione(TipiSpesecomboBoxMix.getValue());
        //così permetto che multipli dello stesso tipo spesa si può inserire -vk
        tipoSpesaList.add(tipoSpesaFx);
        tabelMix.setItems(tipoSpesaList);
        tabelMix.refresh();


    }

    @FXML
    void inserisciNuovoTipoSpesa(ActionEvent event) {

        try {

            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/fxml/inserisciTS.fxml"));
            AnchorPane frame = fxmlLoader.load();

            Stage window2 = new Stage();
            Scene ls = new Scene(frame);

            window2.setScene(ls);
            window2.show();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @FXML
    void salvaTutto(ActionEvent event) throws Exception {


        NotaSpesaService notaSpesaService = new NotaSpesaService();
        notaSpesaService.insertNotaSpesaFx(agenteField.getText(), matricolaField.getText(), ufficioField.getText(),
                partenzaField.getText(), ritornoField.getText(), viaggioField.getText());

        agenteField.clear();
        matricolaField.clear();
        ufficioField.clear();
        viaggioField.clear();
        partenzaField.clear();
        ritornoField.clear();
        Platform.exit();

    }


}
