package com.nsi.rsni.service;

import com.nsi.rsni.dao.impl.DaoFactory;
import com.nsi.rsni.dao.impl.TipoSpesaDaoImpl;
import com.nsi.rsni.exception.BusinessException;
import com.nsi.rsni.pojo.TipoSpesa;
import com.nsi.rsni.pojo.pojoFX.TipoSpesaFx;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Created by v.chiuselli on 05/12/2016.
 */
public class TipoSpesaService {


    TipoSpesaDaoImpl tipoSpesaDao = new TipoSpesaDaoImpl();


    public TipoSpesaService() {

        tipoSpesaDao = new DaoFactory().getDaoTipoSpesa();
    }


    public String insertTipoSpesaFx(String descrizione, String iva, String importo) throws Exception {
        this.tipoSpesaDao.beginTransaction();
        String id_tipo_spesa = tipoSpesaDao.inserisciTipoSpesa(descrizione, iva, importo);
        this.tipoSpesaDao.endTransaction();
        return id_tipo_spesa;
    }





    public ObservableList<String> getListTipoSpesaDescrizioniFx() throws BusinessException {
        this.tipoSpesaDao.beginTransaction();
        ObservableList<String> list = tipoSpesaDao.getListaTipoSpesaDescrizioniFx();
        this.tipoSpesaDao.endTransaction();
        return list;


    }

    public TipoSpesaFx getByDescrizione(String descrizione) throws Exception {
        this.tipoSpesaDao.beginTransaction();
        TipoSpesaFx result= tipoSpesaDao.getByDescrizioneImpl(descrizione);
        this.tipoSpesaDao.endTransaction();
        return result;
    }
}
