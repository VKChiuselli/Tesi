package com.nsi.rsni.dao.impl;

import com.nsi.rsni.dao.TipoSpesaDaoInterface;
import com.nsi.rsni.pojo.pojoFX.TipoSpesaFx;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.List;

/**
 * Created by v.chiuselli on 05/12/2016.
 */
public class TipoSpesaDaoImpl extends BaseDaoServiceImpl implements TipoSpesaDaoInterface {
    @Override
    public void persist(TipoSpesaFx entity) throws Exception {
        getCurrentSession().persist(entity);
        return;
    }

    @Override
    public String save(TipoSpesaFx entity) throws Exception {
        return (String) getCurrentSession().save(entity);
    }

    @Override
    public void update(TipoSpesaFx entity) throws Exception {
        getCurrentSession().update(entity);
        return;
    }

    @Override
    public TipoSpesaFx findById(String s) throws Exception {
        if (getCurrentSession() == null) {
            openCurrentSession();
        }
        return getCurrentSession().get(TipoSpesaFx.class, s);
    }

    @Override
    public void delete(TipoSpesaFx entity) throws Exception {
        getCurrentSession().delete(entity);
        return;
    }

    @Override
    public List<TipoSpesaFx> findAll() throws Exception {
        List<TipoSpesaFx> listaResult = getCurrentSession()
                .createQuery("from TipoSpesa").list();


        return listaResult;
    }

    @Override
    public String inserisciTipoSpesa(String descrizione, String importo, String iva) throws Exception {

        String risposta;

        TipoSpesaFx tipoSpesa = new TipoSpesaFx();
        tipoSpesa.setDescrizione(descrizione);
        tipoSpesa.setImporto(importo);
        tipoSpesa.setIva(iva);

        return risposta = (String) save(tipoSpesa);


    }


    public ObservableList<String> getListaTipoSpesaDescrizioniFx() {

        ObservableList<String> result = FXCollections.observableArrayList();
        List<TipoSpesaFx> listaResult = getCurrentSession().createQuery("from TipoSpesa").list();
// potevo anche prendere con la query direttamente TUTTE le stringhe di descrizione from TipoSpesa where u descrizione
        for (TipoSpesaFx tipoSpesaFx : listaResult) {
            result.add(tipoSpesaFx.get_descrizione());
        }


        return result;
    }

    @Override
    public TipoSpesaFx getByDescrizioneImpl(String descrizione) throws Exception {


      //  TipoSpesaFx result;


        if (getCurrentSession() == null) {
            openCurrentSession();
        }
        return (TipoSpesaFx) openCurrentSession().get(TipoSpesaFx.class, descrizione);



    }


}
