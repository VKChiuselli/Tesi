package com.nsi.rsni.dao;


import com.nsi.rsni.pojo.pojoFX.TipoSpesaFx;
import javafx.collections.ObservableList;

/**
 * Created by v.chiuselli on 05/12/2016.
 */
public interface TipoSpesaDaoInterface extends  BaseDaoInterface<TipoSpesaFx, String> {

    public String inserisciTipoSpesa(String descrizione, String importo, String iva)throws Exception;
    public ObservableList<String> getListaTipoSpesaDescrizioniFx();
    public TipoSpesaFx getByDescrizioneImpl(String descrizione)throws Exception;

}
