package com.nsi.rsni;


import com.nsi.rsni.dao.impl.TipoSpesaDaoImpl;
import com.nsi.rsni.pojo.TipoSpesa;
import com.nsi.rsni.pojo.pojoFX.NotaSpesaFx;
import com.nsi.rsni.service.NotaSpesaService;
import com.nsi.rsni.service.TipoSpesaService;
import javafx.application.Application;

import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

/**
 * Created by acerioni on 06/09/2016.
 */
public class MainCrud extends Application {

    private static Stage primaryStage;


    @Override
    public void start(Stage primaryStage) throws Exception {

        System.out.println("Hello Vittorio!");

        try {


            URL fxmlpath = this.getClass().getResource("/fxml/crudNotaSpesa.fxml");


            FXMLLoader loader = new FXMLLoader();
            AnchorPane insertCrud = loader.load(fxmlpath);


            Scene scene = new Scene(insertCrud);

            primaryStage.setTitle("Inserisci Note Spese");
            primaryStage.setScene(scene);
            primaryStage.show();


        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public static void main() throws Exception {


        System.out.println("entro qui");
        TipoSpesaService tipoSpesaService = new TipoSpesaService();
        tipoSpesaService.insertTipoSpesaFx("desc1", "importo1", "iva1");
        tipoSpesaService.insertTipoSpesaFx("desc2", "importo2", "iva2");
        Application.launch();


    }


}
