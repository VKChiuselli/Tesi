package com.nsi.rsni.pojo;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "NotaSpesa")
public class NotaSpesa extends Base implements Serializable{

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "id_nota_spese", unique = true)
    private String id;


    @Column(name = "agente", nullable = false, length = 45)
    private String agente;


    @Column(name = "matricola", nullable = false, length = 45)
    private String matricola;

    @Column(name = "ufficio", nullable = false, length = 45)
    private String ufficio;


    @Column(name = "viaggio", nullable = false, length = 100)
    private String viaggio;

    @Column(name = "partenza", nullable = false, length = 100)
    private String partenza;

    @Column(name = "ritorno", nullable = false, length = 100)
    private String ritorno;

    public String getAgente() {
        return agente;
    }

    public void setAgente(String agente) {
        this.agente = agente;
    }

    public String getViaggio() {
        return viaggio;
    }

    public void setViaggio(String viaggio) {
        this.viaggio = viaggio;
    }

    //costruttore
    public NotaSpesa(){}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMatricola() {
        return matricola;
    }

    public void setMatricola(String matricola) {
        this.matricola = matricola;
    }

    public String getUfficio() {
        return ufficio;
    }

    public void setUfficio(String ufficio) {
        this.ufficio = ufficio;
    }

    public String getPartenza() {
        return partenza;
    }

    public void setPartenza(String partenza) {
        this.partenza = partenza;
    }

    public String getRitorno() {
        return ritorno;
    }

    public void setRitorno(String ritorno) {
        this.ritorno = ritorno;
    }
}









